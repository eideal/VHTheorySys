from MadGraphControl.MadGraphUtils import *

import os

masses={}
runNumber = runArgs.runNumber
syst_mod = None
use_Tauola = False
use_METfilter=False
therun = -1

# Extenstions for the 1- and 2-step grids used in the 1- and 2-lepton analyses

# 2-step squark grids with and without slepton 
pointsSS2step = [[205,45],[245,5],[225,145],[265,105],[305,65],[345,25],[325,165],[365,125],[405,85],[445,45],[485,5],[425,185],[465,145],[505,105],[545,65]] 

# 2-step gluino grid with slepton
pointsGG2step = [[905,825],[945,625],[1025,865],[185,105],[265,185],[345,105]]

# 1-step squark grid x
points2x = [[300,0.16],[300,0.3],[400,0.25],[400,0.45]] 

squarksl = []
for anum in [1,2,3,4]:
    squarksl += [str(1000000+anum),str(-1000000-anum)]


# Assigning run numbers
therun = runNumber-179816
if therun>=0 and therun<len(pointsSS2step):
    log.info('Registered generation of grid extension: SS two step with slepton '+str(therun))
    for q in squarksl: masses[q] = pointsSS2step[therun][0]
    masses['1000022'] = pointsSS2step[therun][1]
    masses['1000023'] = 0.5*(pointsSS2step[therun][0]+pointsSS2step[therun][1])
    masses['1000024'] = 0.5*(pointsSS2step[therun][0]+pointsSS2step[therun][1])
    masses['1000011'] = 0.25*(3.*pointsSS2step[therun][1]+pointsSS2step[therun][0])
    masses['1000012'] = 0.25*(3.*pointsSS2step[therun][1]+pointsSS2step[therun][0])
    masses['1000013'] = 0.25*(3.*pointsSS2step[therun][1]+pointsSS2step[therun][0])
    masses['1000014'] = 0.25*(3.*pointsSS2step[therun][1]+pointsSS2step[therun][0])
    masses['1000015'] = 0.25*(3.*pointsSS2step[therun][1]+pointsSS2step[therun][0])
    masses['1000016'] = 0.25*(3.*pointsSS2step[therun][1]+pointsSS2step[therun][0])
    stringy = str(int(pointsSS2step[therun][0]))+'_'+str(int(masses['1000024']))+'_'+str(int(masses['1000016']))+'_'+str(int(pointsSS2step[therun][1]))
    gentype='SS'
    decaytype='twostepCN_slepton'
    njets=1
    use_decays=False
    use_Tauola=False

therun = runNumber-179831
if therun>=0 and therun<len(pointsSS2step):
    log.info('Registered generation of grid extension: SS two step with WWZZ '+str(therun))
    for q in squarksl: masses[q] = pointsSS2step[therun][0] 
    masses['1000022'] = pointsSS2step[therun][1]
    masses['1000024'] = 0.5*(pointsSS2step[therun][0]+pointsSS2step[therun][1])
    masses['1000023'] = 0.5*(masses['1000024']+pointsSS2step[therun][1])
    stringy = str(int(pointsSS2step[therun][0]))+'_'+str(int(masses['1000024']))+'_'+str(int(pointsSS2step[therun][1]))
    gentype='SS'
    decaytype='twostep'
    njets=1
    use_decays=False
    use_Tauola=False

therun = runNumber - 179846
if therun>=0 and therun<len(pointsGG2step):
    log.info('Registered generation of grid extension: GG two step with slepton '+str(therun))
    masses['1000021'] = pointsGG2step[therun][0]
    masses['1000022'] = pointsGG2step[therun][1]
    masses['1000023'] = 0.5*(pointsGG2step[therun][0]+pointsGG2step[therun][1])
    masses['1000024'] = 0.5*(pointsGG2step[therun][0]+pointsGG2step[therun][1])
    masses['1000011'] = 0.25*(3.*pointsGG2step[therun][1]+pointsGG2step[therun][0])
    masses['1000012'] = 0.25*(3.*pointsGG2step[therun][1]+pointsGG2step[therun][0])
    masses['1000013'] = 0.25*(3.*pointsGG2step[therun][1]+pointsGG2step[therun][0])
    masses['1000014'] = 0.25*(3.*pointsGG2step[therun][1]+pointsGG2step[therun][0])
    masses['1000015'] = 0.25*(3.*pointsGG2step[therun][1]+pointsGG2step[therun][0])
    masses['1000016'] = 0.25*(3.*pointsGG2step[therun][1]+pointsGG2step[therun][0])
    stringy = str(int(pointsGG2step[therun][0]))+'_'+str(int(masses['1000024']))+'_'+str(int(masses['1000016']))+'_'+str(int(pointsGG2step[therun][1]))
    gentype='GG'
    decaytype='twostepCN_slepton'
    njets=1
    use_decays=False
    use_Tauola=False

therun = runNumber - 179852
if therun>=0 and therun<len(points2x):
    mLSP=60
    log.info('Registered generation of grid extension: one-step SS in X point '+str(therun))
    for q in squarksl: masses[q] = points2x[therun][0]
    masses['1000022'] = mLSP
    masses['1000024'] = points2x[therun][1] * (points2x[therun][0]-mLSP) + mLSP
    stringy = str(int(points2x[therun][0]))+'_'+str(int(masses['1000024']))+'_'+str(int(mLSP))
    gentype='SS'
    decaytype='onestepCC'
    njets=1
    use_decays=False
    use_Tauola=False

if njets<0:
    log.fatal('You have requested an unknown run number!  '+str(runNumber)+' could not be decoded.')
if not 'runArgs' in dir() and runArgs is not None:
    log.fatal('Running generation in madgraph outside of the job transforms is not currently supported, sorry.')
    raise RunTimError('Cannot run generation outside of job transforms.')
if not hasattr(runArgs,"randomSeed") or not hasattr(runArgs,'maxEvents'):
    log.fatal('You missed either random seed or max events in your runargs.  Bailing out.')
    raise RunTimeError('Random seed or max events not specified')
if not hasattr(runArgs,'firstEvent'):
    log.info('No first event found.  Assuming we should not skip events in MadGraph generation')
    skip_events=0
else:
    skip_events=runArgs.firstEvent-1
    if skip_events<0: skip_events=0


evt_multiplier = 4.0
if hasattr(runArgs,'EventMultiplier'):
    evt_multiplier = float(runArgs.EventMultiplier)
    log.warning('Using event multiplier override: '+str(evt_multiplier))
    log.warning('This should only be done if jobs are crashing, and please fix the multiplier in a future setup')

if runArgs.maxEvents>0:
    nevts=runArgs.maxEvents*evt_multiplier
else:
    nevts=5000
    evgenConfig.minevents = nevts
    nevts = nevts*evt_multiplier

rand_seed=runArgs.randomSeed

if hasattr(runArgs,'ecmEnergy'):
    beamEnergy = runArgs.ecmEnergy / 2.
else:
    beamEnergy = 4000.

[qcut,outputDS] = SUSY_StrongSM_Generation(run_number=runNumber,gentype=gentype,decaytype=decaytype,masses=masses,stringy=stringy,nevts=nevts,rand_seed=rand_seed, njets=njets, use_decays=use_decays, skip_events=skip_events, syst_mod=syst_mod, beamEnergy=beamEnergy)

runArgs.qcut = qcut
runArgs.inputGeneratorFile = outputDS
runArgs.syst_mod = syst_mod
runArgs.decaytype = decaytype
runArgs.gentype = gentype
runArgs.use_Tauola = use_Tauola
runArgs.use_METfilter = use_METfilter
        
include('MC12JobOptions/MadGraphControl_SimplifiedModelPostInclude.py')

evgenConfig.contact  = [ "genest@lpsc.in2p3.fr" ]
evgenConfig.keywords += ['squark','gluino','one_step','two_step','slepton']
evgenConfig.description = 'squark and gluino production one or two step with or without slepton in simplified model - extension of pre-existing grids'
