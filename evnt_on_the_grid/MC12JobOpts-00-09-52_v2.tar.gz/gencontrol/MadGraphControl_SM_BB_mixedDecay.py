from MadGraphControl.MadGraphUtils import *

import os

masses={}
runNumber = runArgs.runNumber
use_Tauola = True
SLHAonly = False
therun = -1
njets = -1

therun = runNumber-179062

points_BB_mixed = []
l_m_sb = [200,300,400,500,600,700,800,900,1000]
#add grid with m_chi2 = m_chi1*2
for m_sb in l_m_sb:
    for m_neut2 in range(100,1001,100):
        if m_neut2 < m_sb:
            points_BB_mixed.append((m_sb,m_neut2,int(m_neut2/2)))
    for m_neut2 in [260]:
        if m_neut2 < m_sb:
            points_BB_mixed.append((m_sb,m_neut2,int(m_neut2/2)))
    m_neut2 = m_sb-5
    points_BB_mixed.append((m_sb,m_neut2,int(m_neut2/2)))
    m_neut2 = m_sb-25
    points_BB_mixed.append((m_sb,m_neut2,int(m_neut2/2)))
#add grid with m_chi1 = 60 GeV
for m_sb in l_m_sb:
    for m_neut2 in range(100,1001,100):
        if m_neut2 < m_sb:
            points_BB_mixed.append((m_sb,m_neut2,60))
    for m_neut2 in [155,180,130]:
        if m_neut2 < m_sb:
            points_BB_mixed.append((m_sb,m_neut2,60))
    points_BB_mixed.append((m_sb,m_sb-5,60))
    points_BB_mixed.append((m_sb,m_sb-25,60))
points_BB_mixed = sorted(points_BB_mixed)

#print len(points)
#print sorted(points)
#The points the validation was performed on:                                                                
#points_BB_mixed = [(650,300,1,False,1),(650,300,1,False,0),(650,300,1,True,0),(650,300,1,True,1),(650,300,1,True,2),(700,400,60,True,2),(700,675,60,True,2),(700,400,60,False,1),(700,675,60,False,1),(200,150,1),(500,150,1),(500,350,1),(500,450,1)]

if therun>=0 and therun<(len(points_BB_mixed)):
    m_sb = points_BB_mixed[therun][0]
    m_chi2 = points_BB_mixed[therun][1]
    m_LSP = points_BB_mixed[therun][2]
    masses['1000005'] = m_sb
    masses['1000023'] = m_chi2
    masses['1000022'] = m_LSP
    gentype='BB'
    decaytype='mixed.3body'
    SLHAexactCopy = False
    if (m_chi2-m_LSP > 90) and (m_chi2-m_LSP < 125):
        decaytype='mixed.Z'
        SLHAexactCopy = False
    elif (m_chi2-m_LSP > 125):
        decaytype='mixed.Higgs'
        SLHAexactCopy = False
    njets=1
    str_info_METfilter = "noFilter"
    str_stringy_METfilter = "noFilter"
    stringy = str(int(points_BB_mixed[therun][0]))+'_'+str(int(points_BB_mixed[therun][1]))+'_'+str(int(points_BB_mixed[therun][2]))+'_'+str_stringy_METfilter
    log.info('Registered generation of sbottom pair production, sbottom to b+LSP; grid point '+str(therun)+' decoded into mass point ' + str(points_BB_mixed[therun]) + ', with ' + str(njets) + ' jets. Using MET filter ' +  str_info_METfilter + '.')
    use_decays=False
    use_Tauola=False
    use_METfilter=False
    #runArgs.METfilterCut = 80.0

    #require exactly ==1 neutralino2 in the decay
    runArgs.useParticleFilter=True
    runArgs.ExclusiveNParticles=True
    runArgs.MinParts=1
    #runArgs.ExclusiveNParticles = points_BB_mixed[therun][3]
    #runArgs.MinParts = points_BB_mixed[therun][4]
    runArgs.RequiredPDGID=1000023

    evt_multiplier = 5.0

if njets<0:
    log.fatal('You have requested an unknown run number!  '+str(runNumber)+' could not be decoded.')
    
if not 'runArgs' in dir() and runArgs is not None:
    log.fatal('Running generation in madgraph outside of the job transforms is not currently supported, sorry.')
    raise RunTimError('Cannot run generation outside of job transforms.')
if not hasattr(runArgs,"randomSeed") or not hasattr(runArgs,'maxEvents'):
    log.fatal('You missed either random seed or max events in your runargs.  Bailing out.')
    raise RunTimeError('Random seed or max events not specified')
if not hasattr(runArgs,'firstEvent'):
    log.info('No first event found.  Assuming we should not skip events in MadGraph generation')
    skip_events=0
else:
    skip_events=runArgs.firstEvent-1
    if skip_events<0: skip_events=0
    
    if runArgs.maxEvents>0:
        nevts=runArgs.maxEvents*evt_multiplier
    else:
        nevts=5000
        evgenConfig.minevents = nevts
        nevts = nevts*evt_multiplier
    
    rand_seed=runArgs.randomSeed

    if hasattr(runArgs,'ecmEnergy'):
        beamEnergy = runArgs.ecmEnergy / 2.
    else:
        beamEnergy = 4000.
        
runArgs.syst_mod=None
[qcut,outputDS] = SUSY_StrongSM_Generation(runArgs.runNumber,gentype,decaytype,masses,stringy,nevts,rand_seed,njets,use_decays,skip_events,runArgs.syst_mod,SLHAonly,beamEnergy,False,{},SLHAexactCopy)

runArgs.qcut = qcut
runArgs.inputGeneratorFile = outputDS
runArgs.decaytype = decaytype
runArgs.gentype = gentype
runArgs.use_Tauola = use_Tauola
runArgs.use_METfilter = use_METfilter




include('MC12JobOptions/MadGraphControl_SimplifiedModelPostInclude.py')

evgenConfig.contact  = [ "alexandru.dafinca@cern.ch" ]
evgenConfig.keywords += ['sbottom', 'cascade_decays']
evgenConfig.description = 'sbottom direct pair production in simplified models; one leg: sb->b+neut2, neut2->H/Z/ff+neut1; other leg sb->b+neut1.'
