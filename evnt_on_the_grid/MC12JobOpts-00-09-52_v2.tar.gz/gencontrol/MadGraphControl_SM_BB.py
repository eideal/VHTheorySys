from MadGraphControl.MadGraphUtils import *

import os

#177586 to 177601
dict_index_syst = {0:'scalefactup',
                   1:'scalefactdown',
                   2:'alpsfactup',
                   3:'alpsfactdown',
                   4:'radhi',
                   5:'radlo',
                   6:'qup',
                   7:'qdown'}
masses={}
runNumber = runArgs.runNumber
use_Tauola = True
SLHAonly = False
therun = -1
njets = -1

# Assigned run numbers the sbottom->b+LSP points for systematic uncertainties: 177175 to 177238
# these cover scalefact, alpsfact, qscale variations and the old recommendations for radiation (FSR)
therun = runNumber-177175
points_BB_directBB = []
for m_sb in [250,350]:
    for deltaM in [10,30,50,100]:
        points_BB_directBB.append((m_sb,m_sb-deltaM))
if therun>=0 and therun<(len(points_BB_directBB)*8):
    m_sb = points_BB_directBB[therun/8][0]
    m_LSP = points_BB_directBB[therun/8][1]
    masses['1000005'] = m_sb
    masses['1000022'] = m_LSP
    gentype='BB'
    decaytype='direct'
    njets=1
    runArgs.syst_mod=dict_index_syst[therun%8]
    str_info_METfilter = "80 GeV"
    str_stringy_METfilter = "MET80"
    stringy = str(int(points_BB_directBB[therun/8][0]))+'_'+str(int(points_BB_directBB[therun/8][1]))+'_'+str_stringy_METfilter+'_'+runArgs.syst_mod
    log.info('Registered generation of sbottom pair production, sbottom to b+LSP; grid point '+str(therun)+' decoded into mass point ' + str(points_BB_directBB[therun/8]) + ', with ' + str(njets) + ' jets. Using MET filter ' +  str_info_METfilter + ' and systematic variation of type '+runArgs.syst_mod)
    use_decays=False
    use_Tauola=False
    use_METfilter=True
    runArgs.METfilterCut = 80.0
    deltaM = m_sb - m_LSP
    if (deltaM<20.1):
        evt_multiplier = 20.0
    elif (deltaM<50.1):
        evt_multiplier = 15.0
    else:
        evt_multiplier = 10.0

# Assigned run numbers the sbottom->b+LSP points for systematic uncertainties: 1775681-177601
# These cover the FSR up/down new recommendations
therun = runNumber-177586
points_BB_directBB = []
for m_sb in [250,350]:
    for deltaM in [10,30,50,100]:
        points_BB_directBB.append((m_sb,m_sb-deltaM))
if therun>=0 and therun<(len(points_BB_directBB)*2):
    dict_index_syst = {0:'moreFSR',
                       1:'lessFSR'}
    m_sb = points_BB_directBB[therun/2][0]
    m_LSP = points_BB_directBB[therun/2][1]
    masses['1000005'] = m_sb
    masses['1000022'] = m_LSP
    gentype='BB'
    decaytype='direct'
    njets=1
    runArgs.syst_mod=dict_index_syst[therun%2]
    str_info_METfilter = "80 GeV"
    str_stringy_METfilter = "MET80"
    stringy = str(int(points_BB_directBB[therun/2][0]))+'_'+str(int(points_BB_directBB[therun/2][1]))+'_'+str_stringy_METfilter+'_'+runArgs.syst_mod
    log.info('Registered generation of sbottom pair production, sbottom to b+LSP; grid point '+str(therun)+' decoded into mass point ' + str(points_BB_directBB[therun/2]) + ', with ' + str(njets) + ' jets. Using MET filter ' +  str_info_METfilter + ' and systematic variation of type '+runArgs.syst_mod)
    use_decays=False
    use_Tauola=False
    use_METfilter=True
    runArgs.METfilterCut = 80.0
    deltaM = m_sb - m_LSP
    if (deltaM<20.1):
        evt_multiplier = 20.0
    elif (deltaM<50.1):
        evt_multiplier = 15.0
    else:
        evt_multiplier = 10.0

if njets<0:
    log.fatal('You have requested an unknown run number!  '+str(runNumber)+' could not be decoded.')
    
if not 'runArgs' in dir() and runArgs is not None:
    log.fatal('Running generation in madgraph outside of the job transforms is not currently supported, sorry.')
    raise RunTimError('Cannot run generation outside of job transforms.')
if not hasattr(runArgs,"randomSeed") or not hasattr(runArgs,'maxEvents'):
    log.fatal('You missed either random seed or max events in your runargs.  Bailing out.')
    raise RunTimeError('Random seed or max events not specified')
if not hasattr(runArgs,'firstEvent'):
    log.info('No first event found.  Assuming we should not skip events in MadGraph generation')
    skip_events=0
else:
    skip_events=runArgs.firstEvent-1
    if skip_events<0: skip_events=0
    
    # Increase the number of MadGraph events for sb->charm+LSP with MET filter
    
    if runArgs.maxEvents>0:
        nevts=runArgs.maxEvents*evt_multiplier
    else:
        nevts=5000
        evgenConfig.minevents = nevts
        nevts = nevts*evt_multiplier
    
    rand_seed=runArgs.randomSeed

    if hasattr(runArgs,'ecmEnergy'):
        beamEnergy = runArgs.ecmEnergy / 2.
    else:
        beamEnergy = 4000.
        
            
[qcut,outputDS] = SUSY_StrongSM_Generation(runArgs.runNumber,gentype,decaytype,masses,stringy,nevts,rand_seed,njets,use_decays,skip_events,runArgs.syst_mod,SLHAonly,beamEnergy)

runArgs.qcut = qcut
runArgs.inputGeneratorFile = outputDS
runArgs.decaytype = decaytype
runArgs.gentype = gentype
runArgs.use_Tauola = use_Tauola
runArgs.use_METfilter = use_METfilter

include('MC12JobOptions/MadGraphControl_SimplifiedModelPostInclude.py')

evgenConfig.contact  = [ "alexandru.dafinca@cern.ch" ]
evgenConfig.keywords += ['sbottom', 'signal_uncertainties']
evgenConfig.description = 'sbottom direct pair production, sb->b+LSP in simplified model, signal uncertainties'
