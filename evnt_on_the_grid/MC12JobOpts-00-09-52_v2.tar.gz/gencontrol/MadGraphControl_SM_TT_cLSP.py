from MadGraphControl.MadGraphUtils import *

import os

dict_index_syst = {0:'scalefactup',
                   1:'scalefactdown',
                   2:'alpsfactup',
                   3:'alpsfactdown',
                   4:'moreFSR',
                   5:'lessFSR',
                   6:'qup',
                   7:'qdown'}

masses={}
runNumber = runArgs.runNumber
syst_mod = None
use_Tauola = True
SLHAonly = False
therun = -1
njets = -1

class Point:
    def __init__(self,runnr,masses,syst,METfilter):
        self.runnr = runnr
        self.masses = masses
        self.syst = syst
        self.METfilter = METfilter

counter = 0
dict_runnr_point_sys = {}
for point_mass in [[100.0,70.0],
                   [100.0,85.0],
                   [100.0,95.0],
                   [200.0,125.0],
                   [200.0,170.0],
                   [200.0,195.0],
                   [300.0,240.0],
                   [300.0,280.0],
                   [300.0,295.0]]:
    for syst in range(0,8):
        runnr = 177602 + counter
        dict_runnr_point_sys[runnr] = Point(runnr,point_mass,syst,"METinclusive")
        counter+=1

for point_mass in [[100.0,70.0],
                   [100.0,85.0],
                   [100.0,95.0],
                   [200.0,125.0],
                   [200.0,170.0],
                   [200.0,195.0]]:
    for syst in range(0,8):
        for METfilter in ['MET180to300','MET300']:
            runnr = 177602 + counter
            dict_runnr_point_sys[runnr] = Point(runnr,point_mass,syst,METfilter)
            counter+=1

therun = runNumber - 177602 #to 177769
if therun>=0 and therun<(len(dict_runnr_point_sys)):
    log.info('Number of points for systematic studies: ' + str(len(dict_runnr_point_sys)))
    point = dict_runnr_point_sys[runNumber]
    m_stop, m_LSP = point.masses
    masses['1000006'] = m_stop
    masses['1000022'] = m_LSP
    gentype='TT'
    decaytype='directCC'
    njets=1
    str_stringy_METfilter = point.METfilter
    syst_mod=dict_index_syst[point.syst]
    if str_stringy_METfilter == 'MET180to300':    
        str_info_METfilter = "180 - 300 GeV"
        runArgs.METfilterCut = 180.0
        runArgs.METfilterUpperCut = 300.0
        use_METfilter=True
        nevts = 100000
    elif str_stringy_METfilter == "MET300":
        str_info_METfilter = "> 300 GeV"
        runArgs.METfilterCut = 300.0
        use_METfilter=True
        nevts = 100000
    elif str_stringy_METfilter == 'METinclusive':
        str_info_METfilter = " - no filter!"
        use_METfilter=False
        deltaM = m_stop - m_LSP
        if (deltaM<20.1):
            evt_multiplier = 3.0
        else:
            evt_multiplier = 2.0

        #fix for failing jobs for DSIDs 177609, 177633, 177641
        if runNumber in [177609, 177633, 177641]:
            evt_multiplier = 4.0

        if runArgs.maxEvents>0:
            nevts=runArgs.maxEvents*evt_multiplier
        else:
            nevts=5000
            evgenConfig.minevents = nevts
            nevts = nevts*evt_multiplier

    stringy = str(int(m_stop))+'_'+str(int(m_LSP))+'_'+str_stringy_METfilter+'_'+syst_mod
    log.info('Registered generation of stop pair production, stop to charm+LSP, systematic uncertainties; grid point '+str(therun)+' decoded into mass point (' + str(m_stop) + ' ' + str(m_LSP) + '), with ' + str(njets) + ' jets. Using MET filter ' +  str_info_METfilter + '. Systematic variation ' + syst_mod + '.')
    use_decays=False
    use_Tauola=False
    

# Assigned run numbers the stop->charm+LSP grid, DS 176266-176321
therun = runNumber-176266
points_TT_directCC = [
    [100.0,70.0],[100.0,80.0],[100.0,85.0],[100.0,90.0],[100.0,95.0],
    [125.0,75.0],[125.0,95.0],[125.0,105.0],[125.0,115.0],[125.0,120.0],
    [150.0,75.0],[150.0,90.0],[150.0,100.0],[150.0,130.0],[150.0,140.0],[150.0,145.0],
    [175.0,100.0],[175.0,125.0],[175.0,155.0],[175.0,160.0],[175.0,165.0],[175.0,170.0],
    [200.0,125.0],[200.0,150.0],[200.0,170.0],[200.0,180.0],[200.0,190.0],[200.0,195.0]]
if therun>=0 and therun<(len(points_TT_directCC)*2):
    syst_mod = None
    m_stop = points_TT_directCC[therun/2][0]
    m_LSP = points_TT_directCC[therun/2][1]
    masses['1000006'] = m_stop
    masses['1000022'] = m_LSP
    gentype='TT'
    decaytype='directCC'
    njets=1
    if (therun%2==0):
        str_info_METfilter = "180 - 300 GeV"
        str_stringy_METfilter = "MET180to300"
    else:
        str_info_METfilter = "> 300 GeV"
        str_stringy_METfilter = "MET300"
        
    stringy = str(int(points_TT_directCC[therun/2][0]))+'_'+str(int(points_TT_directCC[therun/2][1]))+'_'+str_stringy_METfilter
    log.info('Registered generation of stop pair production, stop to charm+LSP; grid point '+str(therun)+' decoded into mass point ' + str(points_TT_directCC[therun/2]) + ', with ' + str(njets) + ' jets. Using MET filter ' +  str_info_METfilter)
    use_decays=False
    use_Tauola=False
    use_METfilter=True

    nevts = 100000
    if therun%2==0:
        runArgs.METfilterCut = 180.0
        #runArgs.METfilterUpperCut = 300.0
        if m_stop == 100:
            eff = 0.0099
        elif (m_stop == 125) or (m_stop == 150):
            eff = 0.0220
        elif (m_stop == 175) or (m_stop == 200):
            eff = 0.0409
    else:
        runArgs.METfilterCut = 300.0
        #runArgs.METfilterUpperCut = 1000000.0
        if m_stop == 100:
            eff = 0.0011
        elif (m_stop == 125) or (m_stop == 150):
            eff = 0.0032
        elif (m_stop == 175) or (m_stop == 200):
            eff = 0.0046

therun = runNumber-178983
points_TT_directCC = [[125,40],
                      [175,90],
                      [225,140],
                      [250,165]]
if therun>=0 and therun<(len(points_TT_directCC)*3):
    syst_mod = None
    m_stop = points_TT_directCC[therun/3][0]
    m_LSP = points_TT_directCC[therun/3][1]
    masses['1000006'] = m_stop
    masses['1000022'] = m_LSP
    gentype='TT'
    decaytype='directCC'
    njets=1
    if (therun%3==0):
        str_info_METfilter = "80 - 180 GeV"
        str_stringy_METfilter = 'MET80to180'
        runArgs.METfilterCut = 80.0
        runArgs.METfilterUpperCut = 180.0
    elif (therun%3==1):
        str_info_METfilter = "180 - 300 GeV"
        str_stringy_METfilter = 'MET180to300'
        runArgs.METfilterCut = 180.0
        runArgs.METfilterUpperCut = 300.0
    else:
        str_info_METfilter = "> 300 GeV"
        str_stringy_METfilter = "MET300"
        runArgs.METfilterCut = 300.0
        
    stringy = str(int(points_TT_directCC[therun/3][0]))+'_'+str(int(points_TT_directCC[therun/3][1]))+'_'+str_stringy_METfilter
    log.info('Registered generation of stop pair production, stop to charm+LSP; grid point '+str(therun)+' decoded into mass point ' + str(points_TT_directCC[therun/3]) + ', with ' + str(njets) + ' jets. Using MET filter ' +  str_info_METfilter)
    use_decays=False
    use_Tauola=False
    use_METfilter=True
    nevts = 100000

if njets<0:
    log.fatal('You have requested an unknown run number!  '+str(runNumber)+' could not be decoded.')
    
if not 'runArgs' in dir() and runArgs is not None:
    log.fatal('Running generation in madgraph outside of the job transforms is not currently supported, sorry.')
    raise RunTimError('Cannot run generation outside of job transforms.')
if not hasattr(runArgs,"randomSeed") or not hasattr(runArgs,'maxEvents'):
    log.fatal('You missed either random seed or max events in your runargs.  Bailing out.')
    raise RunTimeError('Random seed or max events not specified')
if not hasattr(runArgs,'firstEvent'):
    log.info('No first event found.  Assuming we should not skip events in MadGraph generation')
    skip_events=0
else:
    skip_events=runArgs.firstEvent-1
    if skip_events<0: skip_events=0
    
    # Increase the number of MadGraph events for stop->charm+LSP with MET filter

    #evt_multiplier = int(1.2/eff) # 1.2 to allow for some matching inefficiency
    #if runArgs.maxEvents>0:
    #    nevts=runArgs.maxEvents*evt_multiplier
    #else:
    #    nevts=5000
    #    evgenConfig.minevents = nevts
    #    nevts = nevts*evt_multiplier

    log.info('Number of events requested from MadGraph: ' + str(nevts))
    log.info('Number of events requested in the final file: ' + str(evgenConfig.minevents))
        
    rand_seed=runArgs.randomSeed

    if hasattr(runArgs,'ecmEnergy'):
        beamEnergy = runArgs.ecmEnergy / 2.
    else:
        beamEnergy = 4000.
        
[qcut,outputDS] = SUSY_StrongSM_Generation(runArgs.runNumber,gentype,decaytype,masses,stringy,nevts,rand_seed,njets,use_decays,skip_events,syst_mod,SLHAonly,beamEnergy)

runArgs.qcut = qcut
runArgs.inputGeneratorFile = outputDS
runArgs.syst_mod = syst_mod
runArgs.decaytype = decaytype
runArgs.gentype = gentype
runArgs.use_Tauola = use_Tauola
runArgs.use_METfilter = use_METfilter

include('MC12JobOptions/MadGraphControl_SimplifiedModelPostInclude.py')

evgenConfig.contact  = [ "alexandru.dafinca@cern.ch" ]
evgenConfig.keywords += ['stop2charmLSP','stop','signal_uncertainties']
evgenConfig.description = 'stop direct pair production, stop->charm+LSP in simplified model, including signal uncertainties'
