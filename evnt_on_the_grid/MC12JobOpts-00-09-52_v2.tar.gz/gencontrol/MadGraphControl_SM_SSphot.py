from MadGraphControl.MadGraphUtils import *

import os

masses={}
runNumber = runArgs.runNumber
syst_mod = None
use_Tauola = False
use_METfilter=False
therun = -1


# Direct squark production with photon filter 
pointsSSphot = []
massS=[100,150,200,250,300]
deltaM=[1,5,10]
for m in massS:
    for dm in deltaM:
        point = [m,m-dm]
        pointsSSphot += [ point ]
massS=[87.5,162.5,237.5]
deltaM=[25]
for m in massS:
    for dm in deltaM:
        point = [m,m-dm]
        pointsSSphot += [ point ]
massS=[100,175,250]
deltaM=[50]
for m in massS:
    for dm in deltaM:
        point = [m,m-dm]
        pointsSSphot += [ point ]

squarks = []
for anum in [1,2,3,4]:
    squarks += [str(1000000+anum),str(-1000000-anum),str(2000000+anum),str(-2000000-anum)]

# Assigning run numbers
therun = runNumber-179549
if therun>=0 and therun<len(pointsSSphot):
    log.info('Registered generation of grid with direct SS with photon point '+str(therun))
    for q in squarks: masses[q] = pointsSSphot[therun][0]
    masses['1000022'] = pointsSSphot[therun][1]
    stringy = str(int(pointsSSphot[therun][0]))+'_'+str(int(pointsSSphot[therun][1]))
    gentype='SSphot'
    decaytype='direct'
    njets=1
    use_decays=False
    use_Tauola=False

if njets<0:
    log.fatal('You have requested an unknown run number!  '+str(runNumber)+' could not be decoded.')
if not 'runArgs' in dir() and runArgs is not None:
    log.fatal('Running generation in madgraph outside of the job transforms is not currently supported, sorry.')
    raise RunTimError('Cannot run generation outside of job transforms.')
if not hasattr(runArgs,"randomSeed") or not hasattr(runArgs,'maxEvents'):
    log.fatal('You missed either random seed or max events in your runargs.  Bailing out.')
    raise RunTimeError('Random seed or max events not specified')
if not hasattr(runArgs,'firstEvent'):
    log.info('No first event found.  Assuming we should not skip events in MadGraph generation')
    skip_events=0
else:
    skip_events=runArgs.firstEvent-1
    if skip_events<0: skip_events=0


evt_multiplier = 4.0
if hasattr(runArgs,'EventMultiplier'):
    evt_multiplier = float(runArgs.EventMultiplier)
    log.warning('Using event multiplier override: '+str(evt_multiplier))
    log.warning('This should only be done if jobs are crashing, and please fix the multiplier in a future setup')

if runArgs.maxEvents>0:
    nevts=runArgs.maxEvents*evt_multiplier
else:
    nevts=5000
    evgenConfig.minevents = nevts
    nevts = nevts*evt_multiplier

rand_seed=runArgs.randomSeed

if hasattr(runArgs,'ecmEnergy'):
    beamEnergy = runArgs.ecmEnergy / 2.
else:
    beamEnergy = 4000.

[qcut,outputDS] = SUSY_StrongSM_Generation(run_number=runNumber,gentype=gentype,decaytype=decaytype,masses=masses,stringy=stringy,nevts=nevts,rand_seed=rand_seed, njets=njets, use_decays=use_decays, skip_events=skip_events, syst_mod=syst_mod, beamEnergy=beamEnergy)

runArgs.qcut = qcut
runArgs.inputGeneratorFile = outputDS
runArgs.syst_mod = syst_mod
runArgs.decaytype = decaytype
runArgs.gentype = gentype
runArgs.use_Tauola = use_Tauola
runArgs.use_METfilter = use_METfilter
        
include('MC12JobOptions/MadGraphControl_SimplifiedModelPostInclude.py')
