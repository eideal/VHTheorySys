export PYTHONPATH=./MC12JobOptions:$PYTHONPATH
export JOBOPTSEARCHPATH=./MC12JobOptions:$JOBOPTSEARCHPATH
mv ./share ./MC12JobOptions
mv ./gencontrol/*.py ./MC12JobOptions
mv ./common/*.py ./MC12JobOptions
rm ./common/README
rmdir ./common
rmdir ./gencontrol
mkdir ./share
mv ./MC12JobOptions/*DEC ./share
mv ./MC12JobOptions/*model ./share
mv ./MC12JobOptions/*txt ./share
mv ./MC12JobOptions/*slha ./share
export DATAPATH=./share:$DATAPATH
