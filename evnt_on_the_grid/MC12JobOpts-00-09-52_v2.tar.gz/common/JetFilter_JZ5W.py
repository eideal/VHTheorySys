## Truth jet filter config for JZ5W
include("MC12JobOptions/JetFilter_JZ5.py")
include("MC12JobOptions/JetFilter_JZXW_Fragment.py")
