assert hasattr(topAlg, "QCDTruthJetFilter")
topAlg.QCDTruthJetFilter.MaxEta=3.0
topAlg.QCDTruthJetFilter.MinEta=9.0
