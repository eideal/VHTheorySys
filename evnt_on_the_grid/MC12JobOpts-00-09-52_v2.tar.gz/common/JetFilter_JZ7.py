## Truth jet filter config for JZ7
include("MC12JobOptions/JetFilter_JZX_Fragment.py")
topAlg.QCDTruthJetFilter.MinPt = 2000.*GeV
