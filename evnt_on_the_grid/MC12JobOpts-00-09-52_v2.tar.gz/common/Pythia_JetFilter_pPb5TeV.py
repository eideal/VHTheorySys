topAlg.Pythia.McEventKey = "PYTHIA_EVENT"
topAlg.QCDTruthJetFilter.McEventKey = "PYTHIA_EVENT"

if hasattr(topSequence,'INav4MomTruthEventBuilder'):
    truthParticleBuilder = getattr(topSequence,'INav4MomTruthEventBuilder')
    truthParticleBuilder.CnvTool.McEvents = "PYTHIA_EVENT"
            
from BoostAfterburner.BoostAfterburnerConf import BoostEvent
topAlg+=BoostEvent()
boost=topAlg.BoostEvent
boost.BetaZ=-0.43448
boost.McInputKey="PYTHIA_EVENT"
boost.McOutputKey="GEN_EVENT"

if "BoostEvent" not in StreamEVGEN.RequireAlgs:
    StreamEVGEN.RequireAlgs +=  ["BoostEvent"]

evgenLog.info("TestHepMC.EnergyDifference=10^7GeV")

from TruthExamples.TruthExamplesConf import TestHepMC
TestHepMC.EnergyDifference = 10000000*GeV

StreamEVGEN.ItemList.remove("McEventCollection#*")
StreamEVGEN.ItemList += ["McEventCollection#GEN_EVENT"]
