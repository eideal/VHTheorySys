## Common setup for ParticleGenerator
from ParticleGenerator.ParticleGeneratorConf import ParticleGenerator
topAlg += ParticleGenerator()
evgenConfig.generators = ["ParticleGenerator"]
