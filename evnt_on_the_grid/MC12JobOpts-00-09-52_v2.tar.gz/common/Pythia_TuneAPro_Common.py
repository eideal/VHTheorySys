## PYTHIA 6 config with Tune A + LEP tune from Professor
include("MC12JobOptions/Pythia_Base_Fragment.py")
topAlg.Pythia.Tune_Name = "PYTUNE_110"
evgenConfig.tune = "A-Pro"
