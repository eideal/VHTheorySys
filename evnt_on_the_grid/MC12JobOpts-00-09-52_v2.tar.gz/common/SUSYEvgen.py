evgenConfig.auxfiles += [ "susy*.txt", "MSSM.model" ]
