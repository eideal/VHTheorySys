## PYTHIA 6 config with profQ2 tune
include("MC12JobOptions/Pythia_Base_Fragment.py")
topAlg.Pythia.Tune_Name = "PYTUNE_129"
evgenConfig.tune = "profQ2"
