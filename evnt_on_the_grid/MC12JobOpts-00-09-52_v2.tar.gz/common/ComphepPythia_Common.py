from EvgenConfig import evgenConfig

evgenConfig.generators += [ "CompHep", "Pythia" ]
