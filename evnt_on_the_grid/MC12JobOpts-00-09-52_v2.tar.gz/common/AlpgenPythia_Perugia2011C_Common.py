## Common config for Alpgen+PYTHIA
include("MC12JobOptions/Pythia_Perugia2011C_Common.py")
include("MC12JobOptions/Pythia_Alpgen.py")
