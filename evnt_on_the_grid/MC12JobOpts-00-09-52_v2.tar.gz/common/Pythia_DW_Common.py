## PYTHIA 6 config with DW tune
include("MC12JobOptions/Pythia_Base_Fragment.py")
topAlg.Pythia.Tune_Name = "PYTUNE_103"
evgenConfig.tune = "DW"
