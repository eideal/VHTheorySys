from EvgenConfig import evgenConfig

evgenConfig.generators += [ "AcerMC", "Pythia" ]
