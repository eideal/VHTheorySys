evgenConfig.auxfiles += [ "MUED.model" ]
