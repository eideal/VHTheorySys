## Truth jet filter common config for all JZx and JZxW
include("MC12JobOptions/JetFilterAkt6.py")
