## Common config for Alpgen+HERWIG+JIMMY
include("MC12JobOptions/Jimmy_AUET2_CTEQ6L1_Common.py")
include("MC12JobOptions/Jimmy_Alpgen.py")
