from Herwigpp_i.Herwigpp_iConf import Herwigpp
topAlg += Herwigpp()
evgenConfig.generators += ["Herwigpp"]

topAlg.Herwigpp.Commands += ["set /Herwig/Model:EW/Sin2ThetaW 0.23113"]
