## Truth jet filter config for JZ6
include("MC12JobOptions/JetFilter_JZX_Fragment.py")
topAlg.QCDTruthJetFilter.MinPt = 1500.*GeV
topAlg.QCDTruthJetFilter.MaxPt = 2000.*GeV
