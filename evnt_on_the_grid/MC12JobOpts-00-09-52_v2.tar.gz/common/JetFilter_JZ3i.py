## Truth jet filter config for JZ3i
include("MC12JobOptions/JetFilter_JZX_Fragment.py")
topAlg.QCDTruthJetFilter.MinPt = 200.*GeV
#topAlg.QCDTruthJetFilter.MaxPt = 500.*GeV
