## Truth jet filter config for JZ3W
include("MC12JobOptions/JetFilter_JZ3.py")
include("MC12JobOptions/JetFilter_JZXW_Fragment.py")
