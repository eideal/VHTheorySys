## Truth jet filter config for JZ7W
include("MC12JobOptions/JetFilter_JZ7.py")
include("MC12JobOptions/JetFilter_JZXW_Fragment.py")
