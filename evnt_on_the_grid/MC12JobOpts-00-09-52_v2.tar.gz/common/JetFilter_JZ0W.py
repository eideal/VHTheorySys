## Truth jet filter config for JZ0W
include("MC12JobOptions/JetFilter_JZ0.py")
include("MC12JobOptions/JetFilter_JZXW_Fragment.py")
