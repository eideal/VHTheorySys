from ReadHepMCFromFile.ReadHepMCFromFileConf import HepMCReadFromFile
topAlg += HepMCReadFromFile()
topAlg.HepMCReadFromFile.AsciiFile="events.hepmc"
evgenConfig.generators += ["HepMCAscii"]
