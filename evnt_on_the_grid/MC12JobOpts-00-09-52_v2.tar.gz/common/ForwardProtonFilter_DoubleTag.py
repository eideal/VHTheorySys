include("MC12JobOptions/ForwardProtonFilter.py")
topAlg.ForwardProtonFilter.double_tag = True
