## Truth jet filter config for JZ1W
include("MC12JobOptions/JetFilter_JZ1.py")
include("MC12JobOptions/JetFilter_JZXW_Fragment.py")
