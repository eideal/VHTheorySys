assert hasattr(topAlg, "QCDTruthJetFilter")
topAlg.QCDTruthJetFilter.MaxEta=-2.7
topAlg.QCDTruthJetFilter.MinEta=-9.0
