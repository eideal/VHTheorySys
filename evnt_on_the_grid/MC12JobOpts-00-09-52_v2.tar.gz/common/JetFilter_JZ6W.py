## Truth jet filter config for JZ6W
include("MC12JobOptions/JetFilter_JZ6.py")
include("MC12JobOptions/JetFilter_JZXW_Fragment.py")
