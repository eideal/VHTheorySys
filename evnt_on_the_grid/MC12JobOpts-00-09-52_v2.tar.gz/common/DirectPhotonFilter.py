## Default configuration of the direct photon filter
from GeneratorFilters.GeneratorFiltersConf import DirectPhotonFilter
if not hasattr(topAlg, "DirectPhotonFilter"):
    topAlg += DirectPhotonFilter()
topAlg.DirectPhotonFilter.Ptcut = 10000.
topAlg.DirectPhotonFilter.Etacut =  2.7
topAlg.DirectPhotonFilter.NPhotons = 1
if "DirectPhotonFilter" not in StreamEVGEN.RequireAlgs:
    StreamEVGEN.RequireAlgs +=  ["DirectPhotonFilter"]
