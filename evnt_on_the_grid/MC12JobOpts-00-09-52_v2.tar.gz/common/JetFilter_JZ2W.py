## Truth jet filter config for JZ2W
include("MC12JobOptions/JetFilter_JZ2.py")
include("MC12JobOptions/JetFilter_JZXW_Fragment.py")
