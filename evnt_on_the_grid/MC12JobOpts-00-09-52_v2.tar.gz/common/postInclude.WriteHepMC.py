## Generate_trf command line postInclude for writing events
## to file in the HepMC IO_GenEvent ASCII format
from TruthExamples.TruthExamplesConf import WriteHepMC
topAlg += WriteHepMC()
