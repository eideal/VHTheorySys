## Truth jet filter config for JZ4W
include("MC12JobOptions/JetFilter_JZ4.py")
include("MC12JobOptions/JetFilter_JZXW_Fragment.py")
